## Version 1.0.0
- Initial release

completed:
extraction > leaked
encryption? purple > data


to do: 
.
.
.
SINGAPORE INSTITUTE OF TECHNOLOGY