import unittest
from src.utils import add, subtract

class TestUtils(unittest.TestCase):
    def test_add(self):
        self.assertEqual(add(1, 2), 3)

    def test_subtract(self):
        self.assertEqual(subtract(2, 1), 1)

if __name__ == "__main__":
    unittest.main()