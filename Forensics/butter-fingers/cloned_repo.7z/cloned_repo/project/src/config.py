config = {
    "setting1": True,
    "setting2": False,
    "setting3": "value"
}