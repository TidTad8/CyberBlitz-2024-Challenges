## Version 1.0.0
- Initial release

completed:
extraction of flags > leaked
encryption? done for both








to be hidden in data folder:
.
.
.
.
.
200917667D ACRA
