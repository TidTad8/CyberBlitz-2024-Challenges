## Installation Instructions

1. Clone the repository.
2. Run setup.sh script.
