import unittest
from src.config import config

class TestConfig(unittest.TestCase):
    def test_config(self):
        self.assertIn("setting1", config)

if __name__ == "__main__":
    unittest.main()